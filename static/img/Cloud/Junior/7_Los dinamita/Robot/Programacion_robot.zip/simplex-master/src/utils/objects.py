import enum


class Objective(enum.Enum):
    MAX = 0
    MIN = 1
