## Algoritmo Simplex ##

### Requisitos

Linux \
Python >= 3

### Instruções ###

baixe o projeto:
```
$ git clone git@github.com:Ramon5/simplex.git
```
### Instale o poetry

```$ curl -sSL https://install.python-poetry.org | python3 - ```


crie o ambiente virtual e ative:
```
$ poetry env use python3.10
```

Instalando os requisitos:

```
$ poetry install
```

### Executando ###

```
$ make run
```
